
package com.mycompany.newquestion01replace;

public class NewQuestion01Replace 
{

    public static void main(String[] args) 
    {
        Encapsulation2 e1=new Encapsulation2("malshan", 22, 85000.00f);
        e1.display();
    }
}
