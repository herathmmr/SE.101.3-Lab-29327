public class Second
{
	public static void main(String[] args)
		{
			System.out.println("malshan herath");
			System.out.println("computer science");
		}
}